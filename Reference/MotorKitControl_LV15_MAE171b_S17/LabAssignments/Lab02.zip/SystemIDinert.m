%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script identifies the plant model for inertia mode
% Written by Cheng-Wei Chen
% 3-31-2017
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;clear;close all;

Filename = 'myData_SystIDinert.txt';   % Put your filename here


fileID = fopen(Filename,'r');
data = fscanf(fileID,'%f %f %f %f',[4 Inf]);   % Properly modify if you change the format
Ts = 0.001;

% Readout the data
t = data(1,:);
d = data(2,:);
y = data(3,:)*(2*pi/400);
u = data(4,:);
v = diff([0 y])/Ts;   % differentiation on y to get velocity

%% duty to velocity
DCgain = mean(v(9000:end));
v = v/DCgain;

figure;
plot(t,v,'g');hold on;
xlabel('time [s]');
ylabel('position');

data = iddata(v',d',Ts);
P = tfest(data,1,0,0);   % estimate the plant model: relative order 1

step(P);

P = P*DCgain;
%% duty to position
figure;
step(P*tf([1],[1 0]),10);hold on;
plot(t,y,'m');

Pinert = P*tf([1],[1 0])   

save ModelInert Pinert;