%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script identifies the plant model for pendumlum mode
% Written by Cheng-Wei Chen
% 3-31-2017
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;clear;close all;

Filename = 'myData_SystIDpend.txt';   % Put your filename here

fileID = fopen(Filename,'r');
data = fscanf(fileID,'%f %f %f %f',[4 Inf]);   % Properly modify if you change the format
Ts = 0.001;

% Readout the data
t = data(1,:);
d = data(2,:);
y = data(3,:)*(2*pi/400);
u = data(4,:);

%% duty to position
figure;
plot(t,y,'g');hold on;
xlabel('time [s]');
ylabel('position');

data = iddata(y(1:2000)',d(1:2000)',Ts);
P = tfest(data,2,0,0);      % estimate the plant model: relative order 2

step(P*u(1));

Ppendulum = P

save ModelPend Ppendulum;