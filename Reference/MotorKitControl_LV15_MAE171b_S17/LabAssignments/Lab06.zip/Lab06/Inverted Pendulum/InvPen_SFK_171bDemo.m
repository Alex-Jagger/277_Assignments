% This scripts designs state observer feedback controller for the motor kit
% Design performed in discrete-time domain
% Cheng-Wei Chen
% 5-24-2017

clc;
clear;
close all;

%% Load the plant model
load InvertedPend
P = Pinv;             % Load discrete-time model P
display('===Open-loop Plant Model===');
[Pa, Pb, Pc, Pd, Ts] = ssdata(P)       % Extract state-space model and sampling rate

%% Design the state feedback controller
display('===State feedback design===');
p_sfk = [0.9 0.93]     % pole placement for state feedback (A-BK)
K = place(Pa,Pb,p_sfk)

%% Design the state observer
display('===State observer design===');
zeta = 0.925;       % damping ratio = 0.925
wn = 374;           % natural frequency = 374 rad/sec
p1a = -zeta*wn+j*sqrt(1-zeta^2)*wn;
p1 = exp(p1a*Ts);
p2 = p1';
p_obs = [p1 p2]                  % pole placement for state observer (A-LC)
L = place(Pa',Pc',p_obs)'

%% Analysis of the closed-loop system
Ga = [Pa-Pb*K                        Pb*K;
      zeros(length(Pa),length(Pa))   Pa-L*Pc];
Gb = [Pb;
      zeros(length(Pa),1)];
Gc = [Pc zeros(1,length(Pa))];
Gd = 0;

G = ss(Ga,Gb,Gc,Gd,Ts);

figure;
step(G);title('Step Response of the closed-loop system (without integral action)')

display('===Closed-loop system===');
damp(G)

%% Analysis of the loop gain
L = ss(Pa-L*Pc-Pb*K,L,K,0,Ts)*ss(Pa,Pb,Pc,0,Ts);

figure;
nyquist(L);title('Nyquist plot of the loop gain (without integral action)')

%% Analysis of the sensitivity function
S = feedback(1,L);

figure;
bode(G);hold on;
bode(L);
bode(S);

title('Bode plots (without integral action)');
legend('Closed-loop system','Loop gain','Sensitivity')
